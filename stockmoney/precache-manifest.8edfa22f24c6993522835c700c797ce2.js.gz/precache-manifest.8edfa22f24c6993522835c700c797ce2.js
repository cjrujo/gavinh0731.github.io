self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "19e25d8c64b4c531792abdbb4f4f42e8",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "78b3e6836fd10617bd1d2d34254522f7",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "b5a145bbd98f30c9194474169c050d9f",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "cc2bae24cf60bbeaf22681b69ad37026",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "37f38f1aa6bb8f2f0c147c890d67c151",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "cd215eacad7fc5fce35d30a7e874e0fb",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "a76abb3e0df2e7f44f57581c62262331",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "3f50896c27a8314623da2d8abf52bd71",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "7241ee95818454e8e14b5f8430926288",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "595b28d3a54f3ad702e9f7d1e576dce3",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "e8dcdc23836827f1f175afd71720bafe",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "19fdfb1438c3b1b94103df394f22eae8",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "4a01d4330b10e31c6048acfe2d9dde98",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "26f6df1248d6980c7250906f19a93c57",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "2250904d90ff6c9847febb50e7e1297e",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "b156283a923fc41a3739bf593de9b1b0",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "a096112cf53f2747051f0f1b85df69ac",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "0122f974547cceca56e95701b39dfe95",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "6374075c6593f96920996eb1e94fd4fd",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "7cef5a3e2a66291f883e49077ff6c739",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "ba76da825456203c1cd593ccdfeacc23",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "25a8d0799179a97736a4c47383e0bdba",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "f3c539e26359cda3199ee0f21a2628c9",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "2887597e736252afdcf648aa7fb13593",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "a73136ea30e200f094c6bd29a8960772",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "fd73962cbd48d7cc56debd50831c5bad",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "3f5be3cf545ef700462b344498309814",
    "url": "/stockmoney/json/chip_borrow.json"
  },
  {
    "revision": "b9d898714914df8c330d1f25fd728bd4",
    "url": "/stockmoney/json/chip_borrow_cols.json"
  },
  {
    "revision": "501f46b639e99ac4f7e30d27d9dc8867",
    "url": "/stockmoney/json/chip_broker.json"
  },
  {
    "revision": "f701ee0bafd7aaf9673d439a3563e29b",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "5705434b750ab052b8f3e507a3bc31ce",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "5474299f53f9dbae2242df778cbbfc8d",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "381acdaa6af7ce6e59ae6fa547bbca99",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "b4c834c415acb84c8baacdc159272181",
    "url": "/stockmoney/json/chip_foreign.json"
  },
  {
    "revision": "1f66416e66912403af00c4d2366c2741",
    "url": "/stockmoney/json/chip_foreign_cols.json"
  },
  {
    "revision": "024fcb5e0197e798c38e9681ae3062a4",
    "url": "/stockmoney/json/chip_holder.json"
  },
  {
    "revision": "672717b58db691e5c491065fd3720da4",
    "url": "/stockmoney/json/chip_holder_cols.json"
  },
  {
    "revision": "f6c76c56c4a9e14def32b888513e1cf9",
    "url": "/stockmoney/json/chip_holder_up.json"
  },
  {
    "revision": "ec1079af0ac2a830213f8b6384b622f7",
    "url": "/stockmoney/json/chip_holder_up_cols.json"
  },
  {
    "revision": "426644deb5a3b616c68a62f146a2ce02",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "60a82514c04d8b46e234b6c3b7db8a4c",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "fd2ae865dde4f5a12b16576aedea67c1",
    "url": "/stockmoney/json/chip_loan.json"
  },
  {
    "revision": "f9dc3e02b8b829e17677de08ed985401",
    "url": "/stockmoney/json/chip_loan_cols.json"
  },
  {
    "revision": "0ac26cd1acc4fd47be9c98390c875e3d",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "0453c094ec1578d8b609550d9e477938",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "e884e4745916d4863fe19bdf07e03523",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "a200b706dabc54bb7fdabc55990a9972",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "60d9cc1a58216f385190e389f4fdd6db",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "3e8dc99836816cdedc952a126db1fa79",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "2a7c0b28863595235c7b9f1bf589bd3c",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "45cd0965cb9b6e5e19f4dc0830ad872c",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "a7dcc4d2208ea7cdf6df3dc9aef42f6d",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "031dd44c6ae7215015d5ae1074c5b4f4",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "45d2f0ad72c2f716491bd292d1278689",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "2548768726a48f7133628aebe17cdd6a",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "60885e75ff404a817f373cfd1c2fb8bf",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "454408ad369b346e0d3bec17b753337f",
    "url": "/stockmoney/json/dk_dies.json"
  },
  {
    "revision": "0842de8223abec6d0d02135b89168710",
    "url": "/stockmoney/json/dk_dies_cols.json"
  },
  {
    "revision": "17c7ceb58c57b1f32268d5d153a02b8f",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "89100efeca7bfb4d95efdab07df62a48",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "322b9481b7913c1008e06412353e4894",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "8a782513b99c4e31cf07aca4745c38e4",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "55cb3bab4fba168bea2768fc532ed84c",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "24c365c317bd950273a6bbe79b14d791",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "ba104fc6466a9b338c3e3bf691674128",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "29e0c2731cf0823c503af4580b581346",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "46fafa344564670598d94a6c4a67160b",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1743dc326779ed0d0955118930c2fdc1",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "206b95ace92efc0de4e6094068038c4d",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "e404cab37f0520f98696b91404654d4b",
    "url": "/stockmoney/json/my_basic.json"
  },
  {
    "revision": "2f5793f3c37c43bf4332b89384b912a3",
    "url": "/stockmoney/json/my_basic_cols.json"
  },
  {
    "revision": "1e64aec63d2dd25a99cdd479d9846f89",
    "url": "/stockmoney/json/my_chip.json"
  },
  {
    "revision": "9a4e135bd706cb00ba1b6ccd50cde83a",
    "url": "/stockmoney/json/my_chip_cols.json"
  },
  {
    "revision": "883ec11a3d99432a7c4712bf5dac036f",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "0def4ed98bbecd3e6a5c7a5cc4d2c620",
    "url": "/stockmoney/json/my_tech.json"
  },
  {
    "revision": "4b39153da2d47c317e3bf1ded1a14cf5",
    "url": "/stockmoney/json/my_tech_cols.json"
  },
  {
    "revision": "6b8fbebde8e3df93db546adb01bda523",
    "url": "/stockmoney/json/my_topforce.json"
  },
  {
    "revision": "355b4a8e70cde4a12ff1467395dee2d2",
    "url": "/stockmoney/json/my_topforce_cols.json"
  },
  {
    "revision": "7c07f083dbf0121bc05c1722360ed670",
    "url": "/stockmoney/json/price_dpct.json"
  },
  {
    "revision": "111c1063358cf2cce62d1c4c3cf2a601",
    "url": "/stockmoney/json/price_dpct_cols.json"
  },
  {
    "revision": "5da0b182656e4856cac72a4b7af56915",
    "url": "/stockmoney/json/price_high.json"
  },
  {
    "revision": "8f986523f915cd6a9dae0cd5f54f5d7f",
    "url": "/stockmoney/json/price_high_cols.json"
  },
  {
    "revision": "ea7bfa51b9698cb4de32b782c5fe13f5",
    "url": "/stockmoney/json/price_mpct.json"
  },
  {
    "revision": "19f8b091eacff631ac486f7a35596c56",
    "url": "/stockmoney/json/price_mpct_cols.json"
  },
  {
    "revision": "42e606e3fdc84d8ae5faa67e04ee6502",
    "url": "/stockmoney/json/price_wpct.json"
  },
  {
    "revision": "06e2f207dffd568d93360a54eff1629d",
    "url": "/stockmoney/json/price_wpct_cols.json"
  },
  {
    "revision": "ab75e0b78c256f2df5c113553a69f338",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "56d227c0fc6a9c5a25f2502cc26148ab",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "bddc3211dba7e04cad64b3d3232453e1",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "d9b52a651b72b7fa689445e631dcb118",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "18106325aa4c7ebdc4958c7802f41146",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "5c125157702e4475325fc62420500833",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "ac6e9f7a2154a906ecffb84a2c5c1a2d",
    "url": "/stockmoney/json/tech_macd.json"
  },
  {
    "revision": "b82649a98059008b579936c35418b441",
    "url": "/stockmoney/json/tech_macd_cols.json"
  },
  {
    "revision": "69b0d78177b1a7147c6e5ab213b08513",
    "url": "/stockmoney/json/tech_makink.json"
  },
  {
    "revision": "f95de82f9706f0ab7fbcddef3c0742ee",
    "url": "/stockmoney/json/tech_makink_cols.json"
  },
  {
    "revision": "e3e95031bd79b46195e486c02424e669",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "bdea5894fe1ee11fe29b8c1b086f8b14",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "9a67052190c2b7ac0c73a2cbf7760b5a",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "131977477f007368864220bd92c5b140",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "a149c43eed173627f8c94c2db72fc47e",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "101ce9c11dafd51f9b77daa28ec5e106",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "048173ba367c0fe9823467856e22ba22",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "6d3ef962007b26c6d23c4c5d7a057cc8",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "d74e5929918bca200ee1e966a0f03f38",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "07c767a967283717369ecc8e0f0f7d99",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "6c922ff28261b78e46fb03add38d9828",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "5af8e03d5ac2fd4ca03652dd2b98f6f0",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "aa2d79dc4a2587875169ae53931701fc",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "b38212d12f678a74ad6a6565339df931",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "b44a729a08fc343f5db59b36bc696b94",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "37f38f1aa6bb8f2f0c147c890d67c151",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "9547a38e0779ca5051efc57b0d7683ec",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "a76abb3e0df2e7f44f57581c62262331",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "8b8f82a7b783c0e6809f6085966011d0",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "7241ee95818454e8e14b5f8430926288",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "554576c4241334e3875daf3cf38cf6b9",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "e8dcdc23836827f1f175afd71720bafe",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "d56b82c6b69d7b6ec34a61103b6d4b7c",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "6f99a8a60e35b64e93e4e87ccbc4e5dd",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "8a9dd1558015a5e24faaf21d3ed37928",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "2250904d90ff6c9847febb50e7e1297e",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "7414a0bece7b0ae6ba9ee75c2773a794",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "a096112cf53f2747051f0f1b85df69ac",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "8bdf4867c64e1d70d511d82f80200271",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "6374075c6593f96920996eb1e94fd4fd",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "f5070d62d68aa9c46f7b181486a26b71",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "ba76da825456203c1cd593ccdfeacc23",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "a64af19665a8cd1c88c78ac03d4aa93b",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "f3c539e26359cda3199ee0f21a2628c9",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "1b04480b981ad1d4602f071b12cddb57",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "a73136ea30e200f094c6bd29a8960772",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "c8c98bc09f1e5a8331f61ebd1ed359af",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "37afed6bf332938bf457759590f15e20",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "8646d7182425cea9182f3f708de3263b",
    "url": "/stockmoney/json_otc/chip_borrow.json"
  },
  {
    "revision": "5a8bd57521f8a67e6f158eda3faacf21",
    "url": "/stockmoney/json_otc/chip_borrow_cols.json"
  },
  {
    "revision": "76f49db0f5a7613793e307946a828db1",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "9e1104c23facfb3f4efe0774ab7f6e04",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "8e7a0bacff28aa1cf9f5825c7712c937",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "b147ecc66eaeabe9d7b2c47d079ed4e9",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "cb725822bf310830ac86771e76bbf7e5",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "987b16861134fa7d925fef8e7bed496a",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "9e1f67c918b55fd9c2153dc91b5ea992",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "79dce6a98cc61675f28207bb8ee66d68",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "fd662be5b96a847b762022d3bf0fe6b4",
    "url": "/stockmoney/json_otc/chip_foreign.json"
  },
  {
    "revision": "e59f62dd4b9a788009bac352d7e91c12",
    "url": "/stockmoney/json_otc/chip_foreign_cols.json"
  },
  {
    "revision": "8258c05715644bc42ebe0e91b384115c",
    "url": "/stockmoney/json_otc/chip_holder.json"
  },
  {
    "revision": "0d80a0b66a710be5c8449613ed1abad2",
    "url": "/stockmoney/json_otc/chip_holder_cols.json"
  },
  {
    "revision": "ea79513cf83ef03964a5075c2956ca6e",
    "url": "/stockmoney/json_otc/chip_holder_up.json"
  },
  {
    "revision": "ec1079af0ac2a830213f8b6384b622f7",
    "url": "/stockmoney/json_otc/chip_holder_up_cols.json"
  },
  {
    "revision": "6f2fa6a4f8f70d019ed23d74edd0c183",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "56a5a51151871b1624874a4fe5a82f83",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "0937f5bc0e0c9467249a7507704b3d97",
    "url": "/stockmoney/json_otc/chip_loan.json"
  },
  {
    "revision": "ee402593614d4650e99e562d17e63538",
    "url": "/stockmoney/json_otc/chip_loan_cols.json"
  },
  {
    "revision": "065b2a2cad3fe53509cc057062b56d5f",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "4466ee075166bd957824b4a6d6c6ddbe",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "d4891988b9911b3cbc5f10c09a4ee470",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "6aa4eed51cba9dc1dc746762256d9659",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "fd5adcb4c5ed1396108a86cd8761eb04",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "b27cd4bd88359e51326cd3dab8215f69",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "74195123b8dd710339155d1f290f443b",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "d770b65af07d9d64a25e81b34c57086f",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "d652fa23fca72dd0c09e41463ab31dd9",
    "url": "/stockmoney/json_otc/dividend_stat.html"
  },
  {
    "revision": "ad77dca0333fa5eb3e532f31a4c0a3e9",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "09a11d016dabcd89215860105e15c4bc",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "cbec2feb676f6a6aa3b239e88e6d6a2c",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "bec80d0d48bffd0a909befe3bdaf3bf9",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "6e18d58a36f9fc2a33f01cedfe00600b",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "5cf8718d2e9ce012e985c85114914ee0",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "297d5aebd0f10fcde9bb1a0e4ac5182e",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "fb803e5cab2e7ad7a2f31cde20de32a0",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "260b5376813e3734a06dab71d8b9bd8a",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "8ebddc517305ecdbe74b28b76566d5b2",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "6050c49dcd02fe1bf54be9c00f3014eb",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "9b4c4be9545c11e770cbe8be386f94cb",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "e36a1205bb33098e0627366331b53d36",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "ecb2998fde71d849b8992a7b6c4e2e3d",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "7070d461fca9f57f911b200dd2fc5bd8",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "bf4091968a9416ed62033f7746eeee19",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "cd31b8a4e6ae79c8381334b713671557",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "192fef50d1b0b739db62b78e28521927",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "06644a4d0d24006b9520f689110d209f",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "962233c053e6db9fe7b8fc8ba435e819",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "c55c440719a695161addc6d1fe124f60",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "49e7cdd201cc3d5a6cd680c3a5aa3c7f",
    "url": "/stockmoney/json_otc/my_basic.json"
  },
  {
    "revision": "12af128c5c8cb61ac4c2042aefe1f0cf",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "ee41870e2a556afa1b4a4cb967744e6d",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "13eb03070e30626dddb2ca3286bb15cb",
    "url": "/stockmoney/json_otc/price_dpct.json"
  },
  {
    "revision": "4a8550ef29380c4fa8d8ac437919bf01",
    "url": "/stockmoney/json_otc/price_dpct_cols.json"
  },
  {
    "revision": "20485baf4d0db3d5419a037887165022",
    "url": "/stockmoney/json_otc/price_mpct.json"
  },
  {
    "revision": "f49e4c8c592ee192541945e62871c3d3",
    "url": "/stockmoney/json_otc/price_mpct_cols.json"
  },
  {
    "revision": "a5b87e3145e76b184b4dfa64f7f1089e",
    "url": "/stockmoney/json_otc/price_wpct.json"
  },
  {
    "revision": "5274839ff9361763e75b70bb12e266d6",
    "url": "/stockmoney/json_otc/price_wpct_cols.json"
  },
  {
    "revision": "ef95aec15c76d53b9269a31299f2d5c3",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "1f3501a7241684346326f6b20fef29ab",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "5b71af6b4c3dbd1d3e562f86151b3382",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "1d1993c61608814513697231793da5ff",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "5ed51c995fca87c74e799102db086b59",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "4f5d6ca8656dd449a555f2892c29746e",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "c9d11d4e9df29eb021efbf7766dd9990",
    "url": "/stockmoney/json_otc/tech_macd.json"
  },
  {
    "revision": "577bd97f15624e7b3f221c82a867b3e1",
    "url": "/stockmoney/json_otc/tech_macd_cols.json"
  },
  {
    "revision": "e3a9086457a0e975a400dfd15bb4f3ff",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "bdea5894fe1ee11fe29b8c1b086f8b14",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "f42f62f9cb07f3d80788bd39c82126b1",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "131977477f007368864220bd92c5b140",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "cfb8ee4bba6a542f092aaac4c17a7347",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "101ce9c11dafd51f9b77daa28ec5e106",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "a91365735ee8621fa4adbaeb043a3596",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "6d3ef962007b26c6d23c4c5d7a057cc8",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "5b21f8ce8ba4dbb8e87e10f9f4551f6e",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "07c767a967283717369ecc8e0f0f7d99",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "282bb688bf19e96633fc",
    "url": "/stockmoney/static/css/app.1201197b.css"
  },
  {
    "revision": "5487711ddcf3f6d565ea",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "658800e4ddcdedaaa231",
    "url": "/stockmoney/static/js/about.6cc0e21f.js"
  },
  {
    "revision": "282bb688bf19e96633fc",
    "url": "/stockmoney/static/js/app.6b76a9f5.js"
  },
  {
    "revision": "5487711ddcf3f6d565ea",
    "url": "/stockmoney/static/js/chunk-vendors.b4926932.js"
  }
]);